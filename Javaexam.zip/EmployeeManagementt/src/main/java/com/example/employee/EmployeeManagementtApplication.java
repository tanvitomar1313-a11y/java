package com.example.employee;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmployeeManagementtApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmployeeManagementtApplication.class, args);
	}

}
